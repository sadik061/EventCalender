<?php
$id = $_GET["search"];
if($_GET["search"]!=""){
    echo "Showing result for '".$_GET["search"]."'";
}
include 'database.php';
$data = array();

    $query = "SELECT * FROM institute where namee like '%".$id."%'";

$statement = $connect->prepare($query);
$statement->execute();
$results_per_page = 10;
$number_of_results = $statement->rowCount();
$number_of_pages = ceil($number_of_results/$results_per_page);
if (!isset($_GET['page'])) {
    $page = 1;
  } else {
    $page =$_GET['page'];
  }
$this_page_first_result = ($page-1)*$results_per_page;
    $query = "SELECT * FROM institute where namee like '%".$id."%' ORDER BY institute_id DESC LIMIT " . $this_page_first_result . "," .  $results_per_page;


$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$from = $this_page_first_result + 1;
$to = $this_page_first_result + $results_per_page;
if($to > $number_of_results){
    $to = $number_of_results;
}

foreach ($result as $row) {

    echo '<div class="message-p pn">
  
  <div class="row">
    <div class="col-md-5">
      <h4 style="padding-left: 2%;"><b>
       '.$row["namee"].'</b>
      </h4>
      <p>'.$row["area"].'</p>
    </div>
    <div class="col-md-5">
      <p >Address: <b>'.$row["address"].'</b></p>
      <p >Address: <b>'.$row["contact"].'</b></p>
    </div>
    <div class="col-md-2">
    <div class=" pull-right hidden-sm hidden-xs">
    <button class="btn btn-xs" id="edit" onClick="edit('.$row["institute_id"].',\''.$row["namee"].'\',\''.$row["area"].'\',\''.$row["contact"].'\',\''.$row["address"].'\')" ><i class="fa fa-pencil "></i></button>
    <button class="btn btn-xs" id="remove" onClick="remove('.$row["institute_id"].')" ><i class="fa fa-trash-o"></i></button>
    </div>
    </div>
  </div>
</div>';
}
echo '<div class="row-fluid">
<div class="span6">
  <div class="dataTables_info" id="hidden-table-info_info">Showing '.$from.' to '.$to .' of '.$number_of_results.' entries</div>
</div>
<div class="span6">
  <div class="dataTables_paginate paging_bootstrap pagination">
    <ul>';


$pagenumber =$page;
$count=0;
if($pagenumber>1){
  echo '<li><a href="institute.php?page=' . ($pagenumber-1) . '&search=' . $id . '">Previous</a></li>';
  echo '<li><a href="institute.php?page=' . 1 . '&search=' . $id . '">' . 1 . '</a></li>';
  echo '<li><a >' . "..." . '</a></li>';
}
for ($page; $page <= $number_of_pages; $page++) {
  if($count > 3){
  break;
  }
  if($pagenumber==$page){
  echo '<li><a style="background-color:#0D7EFF;color:white;" href="institute.php?page=' . $page . '&search=' . $id . '">' . $page . '</a></li>';
}else{
  echo '<li><a disabled href="institute.php?page=' . $page . '&search=' . $id . '">' . $page . '</a></li>';
}
  $count++;
}
if($pagenumber<($number_of_pages-3)){
  echo '<li><a class="disabled" style=" cursor: not-allowed;opacity: 0.5;">' . "..." . '</a></li>';
  echo '<li><a href="institute.php?page=' . $number_of_pages . '&search=' . $id . '">' . $number_of_pages . '</a></li>';
  }
  if($pagenumber<$number_of_pages){
    echo '<li><a href="institute.php?page=' . ($pagenumber+1) . '&search=' . $id . '">Next</a></li>';
  }
echo '</ul>
  </div>
</div>
</div>';
?>